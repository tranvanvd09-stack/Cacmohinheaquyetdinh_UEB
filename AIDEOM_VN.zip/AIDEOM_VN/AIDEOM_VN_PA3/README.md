# AIDEOM-VN PA3

Mở file index.html bằng Chrome/Edge.
