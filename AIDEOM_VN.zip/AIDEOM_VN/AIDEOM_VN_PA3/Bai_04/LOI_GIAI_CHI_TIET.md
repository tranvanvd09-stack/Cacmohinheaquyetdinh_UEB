# Bài 4. LP phân bổ ngân sách số theo ngành - vùng

## 1. Mục tiêu bài
Làm riêng bài 4 theo dữ liệu gốc trong thư mục `data_goc/`, không trộn lẫn với bài khác. Kết quả CSV của bài này nằm ngay trong cùng thư mục.

## 2. Mô hình sử dụng
LP 6 vùng x 4 hạng mục, ngân sách 50.000 tỷ, ràng buộc tối thiểu/tối đa vùng, nhân lực và công bằng chỉ số số hóa.

## 3. Kết quả chính
Z có công bằng = 54,192.00; Z không công bằng = 68,750.00; chi phí công bằng = 14,558.00.

## 4. Bảng kết quả đi kèm

### bai04_lp_allocation_fair.csv

| Unnamed: 0   |   I |     D |   AI |    H |
|:-------------|----:|------:|-----:|-----:|
| NMM          |   0 |  8880 |    0 | 3120 |
| RRD          |   0 |     0 | 5000 |    0 |
| NCC          |   0 |   380 |    0 | 4620 |
| CH           |   0 | 11880 |    0 |  120 |
| SE           |   0 |     0 | 7980 |    0 |
| MD           |   0 |  3880 |    0 | 4140 |

### bai04_lp_allocation_no_fair.csv

| Unnamed: 0   |   I |   D |    AI |     H |
|:-------------|----:|----:|------:|------:|
| NMM          |   0 |   0 |     0 |  5000 |
| RRD          |   0 |   0 | 12000 |     0 |
| NCC          |   0 |   0 |     0 |  5000 |
| CH           |   0 |   0 |     0 | 11000 |
| SE           |   0 |   0 | 12000 |     0 |
| MD           |   0 |   0 |     0 |  5000 |

## 5. Cách xem biểu đồ
Mở `dashboard/index.html`, chọn tab Bài 04. Biểu đồ trong dashboard là Plotly tương tác, có thể rê chuột xem số liệu, phóng to, tải ảnh và chỉnh các tham số ở những bài có slider.
