Mở index.html bằng Chrome/Edge.
