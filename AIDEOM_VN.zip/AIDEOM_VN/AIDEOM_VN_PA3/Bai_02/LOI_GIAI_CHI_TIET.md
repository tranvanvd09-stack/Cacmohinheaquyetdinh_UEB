# Bài 2. Phân bổ ngân sách đơn giản theo 4 hạng mục đầu tư số

## 1. Mục tiêu bài
Làm riêng bài 2 theo dữ liệu gốc trong thư mục `data_goc/`, không trộn lẫn với bài khác. Kết quả CSV của bài này nằm ngay trong cùng thư mục.

## 2. Mô hình sử dụng
Max Z = 0.85x1 + 1.20x2 + 0.95x3 + 1.35x4, với ràng buộc tổng ngân sách, mức tối thiểu từng hạng mục và tỷ lệ ưu tiên số.

## 3. Kết quả chính
LP ngân sách cho hạ tầng số, dữ liệu/AI, nhân lực số và R&D; có thanh chỉnh ngân sách và mức tối thiểu nhân lực trong dashboard.

## 4. Bảng kết quả đi kèm

### bai02_lp_budget.csv

| budget    |   I |   AI_data |   Human |   RD |      Z | status                                                          |
|:----------|----:|----------:|--------:|-----:|-------:|:----------------------------------------------------------------|
| 100       |  25 |        15 |      20 |   40 | 112.25 | Optimization terminated successfully. (HiGHS Status 7: Optimal) |
| 120       |  25 |        15 |      20 |   60 | 139.25 | Optimization terminated successfully. (HiGHS Status 7: Optimal) |
| 140       |  25 |        15 |      20 |   80 | 166.25 | Optimization terminated successfully. (HiGHS Status 7: Optimal) |
| 100_H>=30 |  25 |        15 |      30 |   30 | 108.25 | Optimization terminated successfully. (HiGHS Status 7: Optimal) |

## 5. Cách xem biểu đồ
Mở `dashboard/index.html`, chọn tab Bài 02. Biểu đồ trong dashboard là Plotly tương tác, có thể rê chuột xem số liệu, phóng to, tải ảnh và chỉnh các tham số ở những bài có slider.
