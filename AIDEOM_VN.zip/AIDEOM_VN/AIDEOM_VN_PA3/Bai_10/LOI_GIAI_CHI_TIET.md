# Bài 10 - Quy hoạch ngẫu nhiên hai giai đoạn

Đã sửa đúng cấu trúc first-stage/second-stage trong đề.

## Kết quả chính

- Giá trị stochastic SP: 98,575.00.
- VSS = 0.00.
- EVPI = 0.00.

## File kết quả

- `bai10_stochastic_first_stage.csv`: quyết định giai đoạn 1.
- `bai10_stochastic_recourse.csv`: quyết định điều chỉnh theo 4 kịch bản.
- `bai10_deterministic_by_scenario.csv`: lời giải xác định theo từng kịch bản.
- `bai10_vss_evpi.csv`: SP, EEV, VSS, EVPI.
- `bai10_robust_regret.csv`: mở rộng robust optimization theo regret.

Web có biểu đồ first-stage, heatmap recourse, bảng VSS/EVPI và biểu đồ robust regret.
