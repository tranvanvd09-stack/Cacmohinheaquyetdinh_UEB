# Bài 5. MIP lựa chọn dự án chuyển đổi số

## 1. Mục tiêu bài
Làm riêng bài 5 theo dữ liệu gốc trong thư mục `data_goc/`, không trộn lẫn với bài khác. Kết quả CSV của bài này nằm ngay trong cùng thư mục.

## 2. Mô hình sử dụng
Biến nhị phân y_j ∈ {0,1}; Max tổng B_j y_j; ràng buộc chi phí, năm 1-2, dependency và số lượng dự án.

## 3. Kết quả chính
MIP chọn tổ hợp dự án tối đa hóa lợi ích với ngân sách, loại trừ, phụ thuộc và dự án bắt buộc.

## 4. Bảng kết quả đi kèm

### bai05_mip_base.csv

| project   | name                         |   cost |   benefit |   selected |
|:----------|:-----------------------------|-------:|----------:|-----------:|
| P1        | Trung tâm dữ liệu Hòa Lạc    |  12000 |     21500 |          0 |
| P2        | Trung tâm dữ liệu phía Nam   |  11500 |     20800 |          1 |
| P3        | 5G toàn quốc                 |  18000 |     32500 |          0 |
| P4        | VNeID 2.0                    |   4500 |      9200 |          0 |
| P5        | DVC quốc gia v3              |   3200 |      6800 |          1 |
| P6        | Y tế số                      |   5800 |     11400 |          0 |
| P7        | Giáo dục số K-12             |   6500 |     12200 |          1 |
| P8        | Trung tâm AI quốc gia        |  15000 |     28500 |          1 |
| P9        | Sandbox fintech              |   2500 |      5800 |          1 |
| P10       | Logistics thông minh         |   7200 |     13800 |          1 |
| P11       | Nông nghiệp số ĐBSCL         |   4800 |      8500 |          0 |
| P12       | Đào tạo 50k kỹ sư AI/bán dẫn |   8500 |     16200 |          1 |

### bai05_mip_budget100.csv

| project   | name                         |   cost |   benefit |   selected |
|:----------|:-----------------------------|-------:|----------:|-----------:|
| P1        | Trung tâm dữ liệu Hòa Lạc    |  12000 |     21500 |          0 |
| P2        | Trung tâm dữ liệu phía Nam   |  11500 |     20800 |          1 |
| P3        | 5G toàn quốc                 |  18000 |     32500 |          0 |
| P4        | VNeID 2.0                    |   4500 |      9200 |          0 |
| P5        | DVC quốc gia v3              |   3200 |      6800 |          1 |
| P6        | Y tế số                      |   5800 |     11400 |          0 |
| P7        | Giáo dục số K-12             |   6500 |     12200 |          1 |
| P8        | Trung tâm AI quốc gia        |  15000 |     28500 |          1 |
| P9        | Sandbox fintech              |   2500 |      5800 |          1 |
| P10       | Logistics thông minh         |   7200 |     13800 |          1 |
| P11       | Nông nghiệp số ĐBSCL         |   4800 |      8500 |          0 |
| P12       | Đào tạo 50k kỹ sư AI/bán dẫn |   8500 |     16200 |          1 |

### bai05_mip_force_P1P2.csv

| project   | name                         |   cost |   benefit |   selected |
|:----------|:-----------------------------|-------:|----------:|-----------:|
| P1        | Trung tâm dữ liệu Hòa Lạc    |  12000 |     21500 |          0 |
| P2        | Trung tâm dữ liệu phía Nam   |  11500 |     20800 |          0 |
| P3        | 5G toàn quốc                 |  18000 |     32500 |          0 |
| P4        | VNeID 2.0                    |   4500 |      9200 |          0 |
| P5        | DVC quốc gia v3              |   3200 |      6800 |          0 |
| P6        | Y tế số                      |   5800 |     11400 |          0 |
| P7        | Giáo dục số K-12             |   6500 |     12200 |          0 |
| P8        | Trung tâm AI quốc gia        |  15000 |     28500 |          0 |
| P9        | Sandbox fintech              |   2500 |      5800 |          0 |
| P10       | Logistics thông minh         |   7200 |     13800 |          0 |
| P11       | Nông nghiệp số ĐBSCL         |   4800 |      8500 |          0 |
| P12       | Đào tạo 50k kỹ sư AI/bán dẫn |   8500 |     16200 |          0 |

### bai05_mip_risk_expected.csv

| project   | name                         |   cost |   benefit |   selected |
|:----------|:-----------------------------|-------:|----------:|-----------:|
| P1        | Trung tâm dữ liệu Hòa Lạc    |  12000 |     21500 |          0 |
| P2        | Trung tâm dữ liệu phía Nam   |  11500 |     20800 |          1 |
| P3        | 5G toàn quốc                 |  18000 |     32500 |          1 |
| P4        | VNeID 2.0                    |   4500 |      9200 |          1 |
| P5        | DVC quốc gia v3              |   3200 |      6800 |          1 |
| P6        | Y tế số                      |   5800 |     11400 |          1 |
| P7        | Giáo dục số K-12             |   6500 |     12200 |          1 |
| P8        | Trung tâm AI quốc gia        |  15000 |     28500 |          0 |
| P9        | Sandbox fintech              |   2500 |      5800 |          1 |
| P10       | Logistics thông minh         |   7200 |     13800 |          0 |
| P11       | Nông nghiệp số ĐBSCL         |   4800 |      8500 |          0 |
| P12       | Đào tạo 50k kỹ sư AI/bán dẫn |   8500 |     16200 |          0 |

## 5. Cách xem biểu đồ
Mở `dashboard/index.html`, chọn tab Bài 05. Biểu đồ trong dashboard là Plotly tương tác, có thể rê chuột xem số liệu, phóng to, tải ảnh và chỉnh các tham số ở những bài có slider.
