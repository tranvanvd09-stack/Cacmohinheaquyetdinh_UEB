# Bài 3. Chỉ số ưu tiên ngành Priority_i cho 10 ngành

## 1. Mục tiêu bài
Làm riêng bài 3 theo dữ liệu gốc trong thư mục `data_goc/`, không trộn lẫn với bài khác. Kết quả CSV của bài này nằm ngay trong cùng thư mục.

## 2. Mô hình sử dụng
Priority_i = tổng trọng số của tăng trưởng, năng suất, lan tỏa, xuất khẩu, lao động, AI readiness và rủi ro tự động hóa đảo chiều.

## 3. Kết quả chính
Xếp hạng 10 ngành bằng chuẩn hóa min-max, có độ nhạy theo trọng số AI readiness.

## 4. Bảng kết quả đi kèm

### bai03_priority_ranking.csv

|   sector_id | sector_name_vi               | sector_name_en                  |   gdp_share_2024_pct |   growth_rate_2024_pct |   labor_million |   labor_share_pct |   export_billion_USD |   digital_index_0_100 |   ai_readiness_0_100 |   fdi_attraction_billion_USD |   spillover_coef_0_1 |   automation_risk_pct |   rd_intensity_pct |   productivity_proxy |   Priority |
|------------:|:-----------------------------|:--------------------------------|---------------------:|-----------------------:|----------------:|------------------:|---------------------:|----------------------:|---------------------:|-----------------------------:|---------------------:|----------------------:|-------------------:|---------------------:|-----------:|
|           8 | Thông tin-Truyền thông-CNTT  | Information-Communication-IT    |                 3.85 |                   7.85 |            0.62 |               1.2 |                178   |                    92 |                   88 |                          4.6 |                 0.92 |                    28 |               1.2  |             6209.68  |   0.803028 |
|           2 | Công nghiệp chế biến chế tạo | Manufacturing                   |                24.1  |                   9.64 |           11.5  |              23.1 |                290.9 |                    68 |                   55 |                         18.6 |                 0.78 |                    42 |               0.62 |             2095.65  |   0.717476 |
|           6 | Tài chính-Ngân hàng-Bảo hiểm | Finance-Banking-Insurance       |                 5.12 |                   7.36 |            0.55 |               1.1 |                  1.2 |                    82 |                   72 |                          1.8 |                 0.85 |                    52 |               0.45 |             9309.09  |   0.586133 |
|          10 | Y tế-Chăm sóc sức khỏe       | Healthcare                      |                 2.85 |                   6.85 |            0.75 |               1.5 |                  0   |                    58 |                   45 |                          1.2 |                 0.6  |                    18 |               0.55 |             3800     |   0.483194 |
|           7 | Logistics-Vận tải-Kho bãi    | Logistics-Transport-Warehousing |                 5.45 |                   9.93 |            1.95 |               3.9 |                  3.1 |                    65 |                   42 |                          2.4 |                 0.72 |                    35 |               0.2  |             2794.87  |   0.48254  |
|           9 | Giáo dục-Đào tạo             | Education-Training              |                 3.85 |                   6.42 |            2.15 |               4.3 |                  0   |                    55 |                   38 |                          0.4 |                 0.65 |                    22 |               0.3  |             1790.7   |   0.439729 |
|           5 | Bán buôn-bán lẻ              | Wholesale-Retail                |                 9.85 |                   7.1  |            7.8  |              15.7 |                  5.5 |                    72 |                   48 |                          3.2 |                 0.55 |                    38 |               0.1  |             1262.82  |   0.418116 |
|           1 | Nông-Lâm-Thủy sản            | Agriculture-Forestry-Fishery    |                11.86 |                   3.27 |           13.2  |              26.5 |                 40.5 |                    28 |                   15 |                          2.1 |                 0.35 |                    18 |               0.15 |              898.485 |   0.347255 |
|           3 | Xây dựng                     | Construction                    |                 7.04 |                   7.45 |            4.8  |               9.6 |                  2.5 |                    35 |                   20 |                          0.8 |                 0.42 |                    25 |               0.18 |             1466.67  |   0.335053 |
|           4 | Khai khoáng                  | Mining                          |                 3.36 |                  -1.2  |            0.3  |               0.6 |                  8.2 |                    50 |                   30 |                          0.5 |                 0.3  |                    55 |               0.22 |            11200     |   0.195324 |

### bai03_sensitivity_ai_weight.csv

| sector_name_vi               |    score |   ai_weight |   rank |
|:-----------------------------|---------:|------------:|-------:|
| Nông-Lâm-Thủy sản            | 0.365532 |        0.05 |      8 |
| Công nghiệp chế biến chế tạo | 0.66872  |        0.05 |      2 |
| Xây dựng                     | 0.341873 |        0.05 |      9 |
| Khai khoáng                  | 0.17316  |        0.05 |     10 |
| Bán buôn-bán lẻ              | 0.368745 |        0.05 |      7 |
| Tài chính-Ngân hàng-Bảo hiểm | 0.493695 |        0.05 |      3 |
| Logistics-Vận tải-Kho bãi    | 0.449537 |        0.05 |      4 |
| Thông tin-Truyền thông-CNTT  | 0.687398 |        0.05 |      1 |
| Giáo dục-Đào tạo             | 0.413125 |        0.05 |      6 |
| Y tế-Chăm sóc sức khỏe       | 0.443737 |        0.05 |      5 |
| Nông-Lâm-Thủy sản            | 0.347255 |        0.1  |      8 |
| Công nghiệp chế biến chế tạo | 0.662681 |        0.1  |      2 |

## 5. Cách xem biểu đồ
Mở `dashboard/index.html`, chọn tab Bài 03. Biểu đồ trong dashboard là Plotly tương tác, có thể rê chuột xem số liệu, phóng to, tải ảnh và chỉnh các tham số ở những bài có slider.
