# Bài 6. TOPSIS xếp hạng 6 vùng ưu tiên đầu tư AI

## 1. Mục tiêu bài
Làm riêng bài 6 theo dữ liệu gốc trong thư mục `data_goc/`, không trộn lẫn với bài khác. Kết quả CSV của bài này nằm ngay trong cùng thư mục.

## 2. Mô hình sử dụng
TOPSIS với tiêu chí lợi ích và chi phí: GRDP/người, FDI, số hóa, AI readiness, lao động đào tạo, R&D, Internet, Gini.

## 3. Kết quả chính
Đồng bằng sông Hồng và Đông Nam Bộ thường đứng đầu do điểm số hóa, AI readiness, FDI và nhân lực cao.

## 4. Bảng kết quả đi kèm

### bai06_topsis_regions.csv

|   region_id | region_name_vi                       | region_name_en                        |   population_million |   grdp_trillion_VND |   grdp_growth_pct |   grdp_per_capita_million_VND |   fdi_registered_billion_USD |   exports_billion_USD |   digital_index_0_100 |   ai_readiness_0_100 |   trained_labor_pct |   gini_coef |   rd_intensity_pct |   internet_penetration_pct |   TOPSIS_expert |   TOPSIS_entropy |
|------------:|:-------------------------------------|:--------------------------------------|---------------------:|--------------------:|------------------:|------------------------------:|-----------------------------:|----------------------:|----------------------:|---------------------:|--------------------:|------------:|-------------------:|---------------------------:|----------------:|-----------------:|
|           5 | Đông Nam Bộ                          | Southeast                             |                 19.2 |                3050 |              7.5  |                         158.9 |                         18.5 |                 128.5 |                    82 |                   75 |                42.5 |       0.385 |               0.78 |                         94 |       0.940152  |         0.92748  |
|           2 | Đồng bằng sông Hồng                  | Red River Delta                       |                 23.5 |                3580 |              7.9  |                         152.3 |                         20   |                 132   |                    78 |                   68 |                36.8 |       0.358 |               0.85 |                         92 |       0.898133  |         0.920332 |
|           3 | Bắc Trung Bộ và duyên hải miền Trung | North Central and South Central Coast |                 20.8 |                1820 |              6.85 |                          87.5 |                          8.2 |                  68.5 |                    55 |                   40 |                27.5 |       0.372 |               0.32 |                         84 |       0.35972   |         0.343884 |
|           6 | Đồng bằng sông Cửu Long              | Mekong Delta                          |                 17.5 |                1409 |              7.3  |                          80.5 |                          2.1 |                  25.7 |                    48 |                   30 |                16.8 |       0.392 |               0.22 |                         78 |       0.171038  |         0.141072 |
|           1 | Trung du miền núi phía Bắc           | Northern Midlands and Mountains       |                 14.2 |                 810 |              8.5  |                          57   |                          3.5 |                  42.5 |                    38 |                   22 |                21.5 |       0.405 |               0.18 |                         72 |       0.0992863 |         0.103715 |
|           4 | Tây Nguyên                           | Central Highlands                     |                  6.1 |                 420 |              7.2  |                          68.9 |                          0.8 |                   2.8 |                    32 |                   18 |                18.2 |       0.412 |               0.15 |                         68 |       0.0312162 |         0.035918 |

## 5. Cách xem biểu đồ
Mở `dashboard/index.html`, chọn tab Bài 06. Biểu đồ trong dashboard là Plotly tương tác, có thể rê chuột xem số liệu, phóng to, tải ảnh và chỉnh các tham số ở những bài có slider.
