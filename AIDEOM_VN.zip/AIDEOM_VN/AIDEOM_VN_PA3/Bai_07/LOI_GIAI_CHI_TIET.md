# Bài 7 - Tối ưu đa mục tiêu Pareto/NSGA-II sampling

Bài này được tách rõ thành 2 bảng dữ liệu:

- `bai07_all_samples.csv`: tập phương án khả thi mô phỏng.
- `bai07_pareto_compromise.csv`: tập nghiệm Pareto không bị trội.

## Hàm mục tiêu

1. Tối đa hóa tăng trưởng: `growth`.
2. Tối thiểu hóa bất bình đẳng phân bổ: `inequality_MAD`.
3. Tối thiểu hóa phát thải: `emission`.
4. Tối thiểu hóa rủi ro an ninh số: `security_risk`.

Một phương án thuộc Pareto nếu không tồn tại phương án khác đồng thời tốt hơn hoặc bằng ở tất cả mục tiêu và tốt hơn ít nhất một mục tiêu.

## Kết quả

- Số mẫu khả thi dùng để vẽ: 800.
- Số nghiệm Pareto hiển thị: 76.
- Phương án thỏa hiệp tốt nhất có `compromise_score = 0.6934`.

Dashboard đã sửa để hiển thị scatter Pareto 2D và 3D, có slider điều chỉnh trọng số tăng trưởng, công bằng, phát thải và rủi ro.
