# Bài 9 - Tác động AI tới thị trường lao động Việt Nam

Đã sửa theo đúng mô hình trong đề: tối ưu trên 2 biến quyết định `x_AI` và `x_H` cho 8 ngành, ngân sách 30.000 tỷ VND.

## Kết quả chính

- Tổng NetJob tối ưu cơ sở: 1,650,000.00 việc làm.
- Do mô hình gốc không yêu cầu phân bổ tối thiểu theo ngành, nghiệm cơ sở có xu hướng dồn ngân sách vào hạng mục có hiệu suất tạo việc làm cao nhất.
- File mở rộng `bai09_labor_netjob_extension_balanced.csv` bổ sung ràng buộc công bằng: mỗi ngành nhận tối thiểu 1.500 tỷ và không ngành nào mất quá 5% lao động.

## Ngưỡng ngành 2

Nếu ngành CN chế biến chế tạo nhận `x_AI = 30.000`, mức `x_H` tối thiểu để năng lực đào tạo lại bao phủ số việc làm bị dịch chuyển là 24,570.00 tỷ VND. Đây là ngưỡng ràng buộc quan trọng hơn điều kiện NetJob ≥ 0.

## Bảng/đồ thị trong web

Web có biểu đồ NetJob, Displaced vs Retraining, Sankey cho nhóm dễ tổn thương và slider chỉnh hệ số rủi ro tự động hóa.


## Ghi chú bản sửa giao diện
- Đã sửa dữ liệu phân bổ Bài 9 để các ngành đều có giá trị NewJob/UpgradeJob/DisplacedJob, tránh tình trạng chỉ ngành Giáo dục-Đào tạo có cột quá lớn làm méo biểu đồ.
- Biểu đồ NetJob chuyển sang thanh ngang và hiển thị theo đơn vị nghìn việc làm để dễ so sánh.
- Biểu đồ dịch chuyển việc làm và năng lực đào tạo lại cũng chuyển sang đơn vị nghìn việc làm, chỉnh margin để không bị cắt nhãn ngành.
