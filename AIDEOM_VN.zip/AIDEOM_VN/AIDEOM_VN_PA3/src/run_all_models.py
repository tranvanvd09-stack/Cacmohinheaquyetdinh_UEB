import os, json, shutil, zipfile, textwrap, math
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import linprog, milp, LinearConstraint, Bounds, minimize
SRC=Path('/mnt/data/pa3_new')
base=list(SRC.glob('*'))[0]
OUT=Path('/mnt/data/AIDEOM_VN_PA3_CU_THE')
if OUT.exists(): shutil.rmtree(OUT)
(OUT/'data').mkdir(parents=True); (OUT/'results').mkdir(); (OUT/'src').mkdir(); (OUT/'report').mkdir()
for f in base.glob('*.csv'): shutil.copy(f, OUT/'data'/f.name)
macro=pd.read_csv(OUT/'data/vietnam_macro_2020_2025.csv')
sectors=pd.read_csv(OUT/'data/vietnam_sectors_2024.csv')
regions=pd.read_csv(OUT/'data/vietnam_regions_2024.csv')
# Add variables for B1
K=np.array([16500,17800,19600,21300,23500,25900.],float); L=np.array([53.6,50.5,51.7,52.4,52.9,53.4]); D=np.array([12,12.7,14.3,16.5,18.3,19.5]); AI=np.array([55.6,60.2,65.4,67,73.8,80.1]); H=np.array([24.1,26.1,26.2,27,28.4,29.2]); Y=macro.GDP_trillion_VND.values.astype(float)
alpha,beta,gamma,delta,theta=.33,.42,.10,.08,.07
A=Y/(K**alpha*L**beta*D**gamma*AI**delta*H**theta); Abar=A.mean(); Yhat=Abar*(K**alpha*L**beta*D**gamma*AI**delta*H**theta); mape=np.mean(abs(Y-Yhat)/Y)*100
# contrib 2020-2025 CAGR logs
logs={"K":np.log(K[-1]/K[0]),"L":np.log(L[-1]/L[0]),"D":np.log(D[-1]/D[0]),"AI":np.log(AI[-1]/AI[0]),"H":np.log(H[-1]/H[0]),"TFP":np.log(A[-1]/A[0])}
coef={"K":alpha,"L":beta,"D":gamma,"AI":delta,"H":theta,"TFP":1}
contrib={k:coef[k]*logs[k]/np.log(Y[-1]/Y[0])*100 for k in logs}
GDP2030=(A[-1]*(1.012**5))*((K[-1]*(1.06**5))**alpha)*((L[-1]*(1.06**5))**beta)*(30**gamma)*(100**delta)*(35**theta)
b1=pd.DataFrame({'year':macro.year,'Y_actual':Y,'K':K,'L':L,'D':D,'AI':AI,'H':H,'TFP_A':A,'Y_hat_Amean':Yhat,'abs_pct_error':abs(Y-Yhat)/Y*100})
b1.to_csv(OUT/'results/bai01_cobb_douglas.csv',index=False)
pd.DataFrame({'factor':list(contrib),'contribution_pct':list(contrib.values())}).to_csv(OUT/'results/bai01_growth_contribution.csv',index=False)
# B2 LP
c=-np.array([.85,1.20,.95,1.35])
Aub=np.array([[1,1,1,1],[-1,0,0,0],[0,-1,0,0],[0,0,-1,0],[0,0,0,-1],[.35,-.65,.35,-.65]],float); bub=np.array([100,-25,-15,-20,-10,0.])
def solve_b2(B=100,x3min=20):
    b=bub.copy(); b[0]=B; b[3]=-x3min
    res=linprog(c,A_ub=Aub,b_ub=b,bounds=[(0,None)]*4,method='highs')
    return res
rows=[]
for B in [100,120,140]:
    res=solve_b2(B); rows.append({'budget':B,'I':res.x[0],'AI_data':res.x[1],'Human':res.x[2],'RD':res.x[3],'Z':-res.fun,'status':res.message})
res30=solve_b2(100,30); rows.append({'budget':'100_H>=30','I':res30.x[0],'AI_data':res30.x[1],'Human':res30.x[2],'RD':res30.x[3],'Z':-res30.fun,'status':res30.message})
pd.DataFrame(rows).to_csv(OUT/'results/bai02_lp_budget.csv',index=False)
# B3 priority
prod=sectors.gdp_share_2024_pct*1000/sectors.labor_million # proxy tr VND/LD arbitrary comparable
df=sectors.copy(); df['productivity_proxy']=prod
cols=['growth_rate_2024_pct','productivity_proxy','spillover_coef_0_1','export_billion_USD','labor_million','ai_readiness_0_100']
def ng(x): return (x-x.min())/(x.max()-x.min())
def nb(x): return (x.max()-x)/(x.max()-x.min())
X=df[cols].apply(ng); risk_good=nb(df.automation_risk_pct); weights=np.array([.15,.15,.20,.15,.10,.20]); wr=.15
df['Priority']=X.values@weights + wr*risk_good.values # risk low is good (use positive good index)
df.sort_values('Priority',ascending=False).to_csv(OUT/'results/bai03_priority_ranking.csv',index=False)
# sensitivity ai weight normalize all factors including risk good
sens=[]
base_w=np.array([.15,.15,.20,.15,.10,.20,.15])
Z=np.c_[X.values,risk_good.values]
for wai in np.arange(.05,.401,.05):
    w=base_w.copy(); w[5]=wai; w=w/w.sum()
    sc=Z@w
    tmp=df[['sector_name_vi']].copy(); tmp['score']=sc; tmp['ai_weight']=round(float(wai),2); tmp['rank']=tmp['score'].rank(ascending=False,method='first').astype(int)
    sens.append(tmp)
pd.concat(sens).to_csv(OUT/'results/bai03_sensitivity_ai_weight.csv',index=False)
# B4 LP regional
reg=['NMM','RRD','NCC','CH','SE','MD']; items=['I','D','AI','H']
beta_mat=np.array([[1.15,.85,.55,1.30],[.95,1.25,1.40,1.05],[1.05,.95,.85,1.15],[1.20,.75,.45,1.35],[.90,1.30,1.55,1.00],[1.10,.85,.65,1.25]])
D0=np.array([38,78,55,32,82,48.]); gam=.002; lam=.68
# variables 24 x + M last. max beta -> min -beta
n=25; c4=np.r_[-beta_mat.flatten(),0]
A=[]; lb=[]; ub=[]
# budget sum <=50000
row=np.zeros(n); row[:24]=1; A.append(row); lb.append(-np.inf); ub.append(50000)
for r in range(6):
 row=np.zeros(n); row[r*4:(r+1)*4]=1; A.append(row); lb.append(5000); ub.append(12000)
row=np.zeros(n); row[3::4]=1; A.append(row); lb.append(12000); ub.append(np.inf)
for r in range(6):
 row=np.zeros(n); row[r*4+1]=gam; row[24]=-1; A.append(row); lb.append(-np.inf); ub.append(-D0[r]) # D0+gam*xD <= M -> gam xD -M <= -D0
 row=np.zeros(n); row[r*4+1]=gam; row[24]=-lam; A.append(row); lb.append(-D0[r]); ub.append(np.inf) # D0+gam*xD >= lam M -> gam*xD-lam M >= -D0
res4=linprog(c4,A_ub=np.array([a for a,l,u in zip(A,lb,ub) if np.isfinite(u)]),b_ub=np.array([u for l,u in zip(lb,ub) if np.isfinite(u)]),A_eq=None,b_eq=None,bounds=[(0,None)]*n,method='highs')
# Oops lower bounds constraints need A_ub -row <= -lb
Aub=[]; bub=[]
for row,l,u in zip(A,lb,ub):
 if np.isfinite(u): Aub.append(row); bub.append(u)
 if np.isfinite(l): Aub.append(-row); bub.append(-l)
res4=linprog(c4,A_ub=np.array(Aub),b_ub=np.array(bub),bounds=[(0,None)]*n,method='highs')
X4=res4.x[:24].reshape(6,4); pd.DataFrame(X4,index=reg,columns=items).to_csv(OUT/'results/bai04_lp_allocation_fair.csv')
# no fairness remove last 12 constraints
A2=[];lb2=[];ub2=[]
for k in range(1+6+1): A2.append(A[k]); lb2.append(lb[k]); ub2.append(ub[k])
Aub2=[];bub2=[]
for row,l,u in zip(A2,lb2,ub2):
 if np.isfinite(u): Aub2.append(row[:24]);bub2.append(u)
 if np.isfinite(l): Aub2.append(-row[:24]);bub2.append(-l)
res4nf=linprog(-beta_mat.flatten(),A_ub=np.array(Aub2),b_ub=np.array(bub2),bounds=[(0,None)]*24,method='highs')
pd.DataFrame(res4nf.x.reshape(6,4),index=reg,columns=items).to_csv(OUT/'results/bai04_lp_allocation_no_fair.csv')
# B5 MIP
names=['Trung tâm dữ liệu Hòa Lạc','Trung tâm dữ liệu phía Nam','5G toàn quốc','VNeID 2.0','DVC quốc gia v3','Y tế số','Giáo dục số K-12','Trung tâm AI quốc gia','Sandbox fintech','Logistics thông minh','Nông nghiệp số ĐBSCL','Đào tạo 50k kỹ sư AI/bán dẫn','KCN bán dẫn Bắc Ninh-Bắc Giang','An ninh mạng SOC','Open Data quốc gia']
C=np.array([12000,11500,18000,4500,3200,5800,6500,15000,2500,7200,4800,8500,20000,3800,1500.]); C12=np.array([8500,7500,12000,3500,2500,4000,4500,9000,1800,5000,3500,5500,13000,2800,1200.]); B=np.array([21500,20800,32500,9200,6800,11400,12200,28500,5800,13800,8500,16200,35000,7500,3800.])
def solve_mip(budget=80000, force12=False, risk=False):
 c=-B.copy();
 if risk:
  p=[]
  for nm in names:
   if 'AI' in nm or 'bán dẫn' in nm: p.append(.65)
   elif 'dữ liệu' in nm or '5G' in nm: p.append(.85)
   elif 'VNeID' in nm or 'DVC' in nm: p.append(.75)
   else:p.append(.80)
  c=-(B*np.array(p))
 A=[]; lb=[]; ub=[]
 A.append(C); lb.append(-np.inf); ub.append(budget)
 A.append(C12); lb.append(-np.inf); ub.append(40000)
 row=np.zeros(15); row[0]=row[1]=1; A.append(row); lb.append(-np.inf); ub.append(1)
 row=np.zeros(15); row[7]=1; row[11]=-1; A.append(row); lb.append(-np.inf); ub.append(0)
 row=np.zeros(15); row[12]=1; row[11]=-1; A.append(row); lb.append(-np.inf); ub.append(0)
 row=np.zeros(15); row[3]=row[4]=1; A.append(row); lb.append(1); ub.append(np.inf)
 row=np.zeros(15); row[13]=1; A.append(row); lb.append(1); ub.append(np.inf)
 row=np.ones(15); A.append(row); lb.append(7); ub.append(11)
 if force12:
  row=np.zeros(15); row[0]=row[1]=1; A.append(row); lb.append(2); ub.append(2)
 constraints=LinearConstraint(np.array(A),np.array(lb),np.array(ub))
 res=milp(c=c,integrality=np.ones(15),bounds=Bounds(np.zeros(15),np.ones(15)),constraints=constraints,options={'disp':False})
 y=np.rint(res.x).astype(int) if res.success else np.zeros(15,int)
 return res,y
for label,budget,force,risk in [('base',80000,False,False),('budget100',100000,False,False),('force_P1P2',80000,True,False),('risk_expected',80000,False,True)]:
 res,y=solve_mip(budget,force,risk); pd.DataFrame({'project':[f'P{i+1}' for i in range(15)],'name':names,'cost':C,'benefit':B,'selected':y}).to_csv(OUT/f'results/bai05_mip_{label}.csv',index=False)
# B6 TOPSIS
criteria=['grdp_per_capita_million_VND','fdi_registered_billion_USD','digital_index_0_100','ai_readiness_0_100','trained_labor_pct','rd_intensity_pct','internet_penetration_pct','gini_coef']
benef=np.array([1,1,1,1,1,1,1,0],bool); Xr=regions[criteria].values.astype(float); w=np.array([.10,.10,.15,.20,.15,.15,.05,.10])
def topsis(X,w,benef):
 R=X/np.sqrt((X**2).sum(axis=0)); V=R*w; Astar=np.where(benef,V.max(0),V.min(0)); Aneg=np.where(benef,V.min(0),V.max(0)); Sstar=np.sqrt(((V-Astar)**2).sum(1)); Sneg=np.sqrt(((V-Aneg)**2).sum(1)); return Sneg/(Sstar+Sneg)
def entropy(X):
 # minmax and reverse cost for entropy weights
 Xp=X.copy().astype(float); Xp[:,~benef]=Xp[:,~benef].max(0)-Xp[:,~benef]
 Xp=(Xp-Xp.min(0))/(Xp.max(0)-Xp.min(0)+1e-12)+1e-12; P=Xp/Xp.sum(0); E=-(1/np.log(len(Xp)))*(P*np.log(P)).sum(0); d=1-E; return d/d.sum()
wr=entropy(Xr); regions.assign(TOPSIS_expert=topsis(Xr,w,benef),TOPSIS_entropy=topsis(Xr,wr,benef)).sort_values('TOPSIS_expert',ascending=False).to_csv(OUT/'results/bai06_topsis_regions.csv',index=False)
# B7 Pareto random feasible using B4 constraints simplification
np.random.seed(42); samples=[]
e=np.array([.42,.55,.48,.32,.62,.38]); rho=np.array([.18,.45,.28,.12,.52,.22]); sig=np.array([.32,.28,.30,.35,.25,.30])
for _ in range(8000):
 totals=5000+np.random.dirichlet(np.ones(6))*20000
 if (totals>12000).any(): continue
 X=np.vstack([np.random.dirichlet(np.ones(4))*totals[i] for i in range(6)])
 if X[:,3].sum()<12000: continue
 # fairness rough
 vals=D0+gam*X[:,1]
 if vals.min()<lam*vals.max(): continue
 f1=(beta_mat*X).sum(); f2=np.abs(totals-totals.mean()).mean(); f3=(e*(X[:,0]+X[:,2])).sum(); f4=(rho*X[:,2]).sum()-(sig*X[:,3]).sum()
 samples.append((f1,f2,f3,f4,*X.flatten()))
P7=pd.DataFrame(samples,columns=['growth','inequality_MAD','emission','security_risk']+[f'{r}_{j}' for r in reg for j in items])
# Pareto: maximize growth, minimize others
F=np.c_[-P7.growth, P7.inequality_MAD, P7.emission, P7.security_risk]
keep=[]
for i in range(len(F)):
 dominated=np.any(np.all(F<=F[i],axis=1)&np.any(F<F[i],axis=1))
 if not dominated: keep.append(i)
Pareto=P7.iloc[keep].copy();
# TOPSIS on Pareto
if len(Pareto)>0:
 Xp=Pareto[['growth','inequality_MAD','emission','security_risk']].values; wp=np.array([.4,.25,.2,.15]); cp=topsis(Xp,wp,np.array([1,0,0,0],bool)); Pareto['compromise_score']=cp

if 'compromise_score' not in Pareto.columns:
 Pareto['compromise_score']=0
Pareto.sort_values('compromise_score',ascending=False).head(200).to_csv(OUT/'results/bai07_pareto_compromise.csv',index=False)
# B8 dynamic scenarios simulate fixed allocations optimized among grid
allocs={'S1_Truyen_thong':[.7,.1,.1,.1],'S2_So_hoa_nhanh':[.25,.45,.15,.15],'S3_AI_dan_dat':[.2,.2,.45,.15],'S4_Bao_trum':[.3,.2,.1,.4],'S5_Can_bang':[.4,.25,.15,.2]}
def sim_alloc(a,shock=False):
 Kt,Dt,AIt,Ht=27500.,20.3,86.,30.; rows=[]; util=0
 for t,year in enumerate(range(2026,2036)):
  Yt=Abar*(Kt**.33)*(54**.42)*(Dt**.10)*(AIt**.08)*(Ht**.07)
  if shock and year==2028: Yt*=.92
  inv=0.22*Yt; Cc=max(Yt-inv,1); util+=(.97**t)*np.log(Cc)
  rows.append({'scenario':None,'year':year,'K':Kt,'D':Dt,'AI':AIt,'H':Ht,'Y':Yt,'C':Cc,'welfare':util})
  Kt=.95*Kt+a[0]*inv; Dt=.88*Dt+a[1]*inv/100; AIt=.85*AIt+a[2]*inv/20; Ht=.98*Ht+a[3]*inv/200
 return rows
rows=[]
for s,a in allocs.items():
 for r in sim_alloc(a,False): r['scenario']=s; rows.append(r)
 for r in sim_alloc(a,True): r['scenario']=s+'_shock'; rows.append(r)
pd.DataFrame(rows).to_csv(OUT/'results/bai08_dynamic_paths.csv',index=False)
# B9 jobs LP
sec8=sectors[~sectors.sector_name_vi.isin(['Khai khoáng','Y tế'])].head(8).copy()
risk=np.array([18,42,25,38,52,35,28,22])/100; a1=np.array([8.5,32.5,12.8,22.4,45.8,28.5,62.5,18.5]); b1=np.array([45,28,35,32,22,30,20,55]); c1=np.array([5.2,62.4,18.5,48.2,72.5,42.8,32.5,12.5]); d1=np.array([50,32,42,38,26,36,24,62])
# variables AI_i,H_i objective max (a1-c1*risk)xAI + b1 xH
coef=np.r_[a1-c1*risk,b1]; c9=-coef
Aub=[];bub=[]; Aub.append(np.ones(16));bub.append(30000)
# NetJob >=0; displaced<=retraincap
for i in range(8):
 row=np.zeros(16); row[i]=-(a1[i]-c1[i]*risk[i]); row[8+i]=-b1[i]; Aub.append(row);bub.append(0)
 row=np.zeros(16); row[i]=c1[i]*risk[i]; row[8+i]=-d1[i]; Aub.append(row);bub.append(0)
res9=linprog(c9,A_ub=np.array(Aub),b_ub=np.array(bub),bounds=[(0,None)]*16,method='highs')
xai=res9.x[:8]; xh=res9.x[8:]; net=(a1-c1*risk)*xai+b1*xh; disp=c1*risk*xai; retr=d1*xh
pd.DataFrame({'sector':sec8.sector_name_vi.values,'x_AI':xai,'x_H':xh,'NewJob':a1*xai,'UpgradeJob':b1*xh,'DisplacedJob':disp,'RetrainingCapacity':retr,'NetJob':net}).to_csv(OUT/'results/bai09_labor_netjob.csv',index=False)
# B10 stochastic LP
J=['I','D','AI','H']; b0=np.array([1,1.1,1.25,.95]); probs=np.array([.3,.45,.2,.05]); bs=np.array([[1.25,1.35,1.55,1.05],[1,1.1,1.25,.95],[.75,.85,.9,1.0],[.4,.5,.55,1.1]])
# Since all positive, first-stage allocate to AI; recourse each scenario to best beta with AI<=0.5*xH? Include constraint yAI_s <= .5 xH. Need LP variables x4 + y16
c10=-np.r_[b0,(probs[:,None]*bs).flatten()]
A=[]; b=[]
row=np.zeros(20);row[:4]=1; A.append(row);b.append(65000)
for s in range(4):
 row=np.zeros(20); row[4+4*s:4+4*s+4]=1; A.append(row);b.append(15000)
 row=np.zeros(20); row[4+4*s+2]=1; row[3]=-.5; A.append(row);b.append(0)
res10=linprog(c10,A_ub=np.array(A),b_ub=np.array(b),bounds=[(0,None)]*20,method='highs')
pd.DataFrame({'item':J,'first_stage_x':res10.x[:4]}).to_csv(OUT/'results/bai10_stochastic_first_stage.csv',index=False)
y10=res10.x[4:].reshape(4,4); pd.DataFrame(y10,index=['lac_quan','co_so','bi_quan','khung_hoang'],columns=J).to_csv(OUT/'results/bai10_stochastic_recourse.csv')
# B11 q-learning
np.random.seed(7); actions=list(allocs.keys()); Q=np.zeros((3,3,3,3,5)); rewards=[]
def discretize(g,d,ai,u): return np.array([np.digitize(g,[4,7]),np.digitize(d,[18,28]),np.digitize(ai,[80,120]),np.digitize(u,[4,7])])
def episode(policy=None,train=False,ep=0):
 state=np.array([1,1,0,1]); Kt,Dt,AIt,Ht=27500.,20.3,86.,30.; total=0; s=state.copy()
 for t in range(10):
  eps=max(.05,1-ep/5000)
  if policy is None:
   a=np.random.randint(5) if np.random.rand()<eps else int(Q[tuple(s)].argmax())
  elif policy=='random': a=np.random.randint(5)
  else: a=policy
  al=np.array(list(allocs.values())[a]); budget=1000
  oldY=Kt**.33*54**.42*Dt**.10*AIt**.08*Ht**.07
  Kt+=al[0]*budget; Dt+=al[1]*budget/100; AIt+=al[2]*budget/20; Ht+=al[3]*budget/200
  newY=Kt**.33*54**.42*Dt**.10*AIt**.08*Ht**.07
  dg=(newY/oldY-1)*100; unem=max(0,8-Ht/8-al[3]*2); cyber=al[2]*(2+AIt/100); em=al[0]*1.2+al[2]*1.4
  r=.4*dg-.25*unem-.2*cyber-.15*em; total+=r
  s2=discretize(dg,Dt,AIt,unem)
  if train:
   Q[tuple(s)+(a,)]+=.1*(r+.95*Q[tuple(s2)].max()-Q[tuple(s)+(a,)])
  s=s2
 return total
for ep in range(2500):
 rewards.append(episode(train=True,ep=ep))
pd.DataFrame({'episode':range(len(rewards)),'reward':rewards}).to_csv(OUT/'results/bai11_q_learning_curve.csv',index=False)
pol=[]
for st in [(1,1,0,1),(0,0,0,2),(2,2,2,0),(1,2,1,1),(0,1,2,2)]:
 a=int(Q[st].argmax()); pol.append({'state':str(st),'action':actions[a],'Q_value':Q[st][a]})
pd.DataFrame(pol).to_csv(OUT/'results/bai11_policy_examples.csv',index=False)
comp=[{'policy':'Q_learning','reward':episode(policy=None)},{'policy':'always_balanced','reward':episode(policy=4)},{'policy':'always_AI','reward':episode(policy=2)},{'policy':'random','reward':np.mean([episode(policy='random') for _ in range(100)])}]
pd.DataFrame(comp).to_csv(OUT/'results/bai11_policy_comparison.csv',index=False)
# B12 scenarios summary from B8 plus risks
b12=pd.read_csv(OUT/'results/bai08_dynamic_paths.csv')
sum12=b12[~b12.scenario.str.contains('shock')].groupby('scenario').tail(1)[['scenario','Y','D','AI','H','welfare']]
# add netjob proxy by scenario from allocation
sum12['risk_note']=['Cơ sở đối chứng','CĐS nhanh, rủi ro hạ tầng vừa','AI cao, cần quản trị dữ liệu','Bao trùm tốt, tăng trưởng chậm hơn','Cân bằng khuyến nghị']
sum12.to_csv(OUT/'results/bai12_integrated_scenarios.csv',index=False)
# summary json
summary={'bai01':{'MAPE':mape,'GDP2030':GDP2030,'top_contrib':max(contrib,key=contrib.get)},'bai02':pd.DataFrame(rows).to_dict('records'),'bai04':{'Z_fair':-res4.fun,'Z_no_fair':-res4nf.fun,'fairness_cost':(-res4nf.fun)-(-res4.fun)},'bai07':{'pareto_count':int(len(Pareto))},'bai09':{'total_netjob':float(net.sum())},'bai10':{'objective':float(-res10.fun)}}
json.dump(summary,open(OUT/'results/summary.json','w'),ensure_ascii=False,indent=2)
# Create Python src
run_code = Path('/mnt/data/build_pa3.py').read_text()
(OUT/'src/run_all_models.py').write_text(run_code,encoding='utf-8')
(OUT/'requirements.txt').write_text('numpy\npandas\nscipy\nplotly (optional, dùng CDN trong web)\n',encoding='utf-8')
# README
(OUT/'README.md').write_text('''# AIDEOM-VN – Phương án 3 cụ thể\n\n- Mở `index.html` trực tiếp bằng Chrome/Edge, không cần localhost.\n- Dữ liệu gốc nằm trong `data/`.\n- Kết quả từng bài nằm trong `results/`, mỗi bài có CSV riêng.\n- Mã chạy lại toàn bộ mô hình nằm trong `src/run_all_models.py`.\n\nCác bài 1–12 được tách thành từng tab rõ ràng. Các biểu đồ trong web là tương tác Plotly; các thanh kéo cho phép chỉnh tham số chính sách và xem kết quả thay đổi ngay trên giao diện.\n''',encoding='utf-8')
# HTML load CSV via embedded data JSON to avoid local fetch restrictions
all_data={}
for f in (OUT/'results').glob('*.csv'):
 all_data[f.stem]=pd.read_csv(f).to_dict('records')
all_data['summary']=summary
# write html
html=f"""
<!doctype html><html lang='vi'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>AIDEOM-VN PA3 – Bài tập cụ thể</title><script src='https://cdn.plot.ly/plotly-2.35.2.min.js'></script>
<style>
body{{margin:0;background:#08111f;color:#eaf0ff;font-family:Inter,Arial,sans-serif}} .layout{{display:flex}} aside{{width:290px;position:fixed;height:100vh;background:#0b1426;border-right:1px solid #24304a;padding:18px;box-sizing:border-box;overflow:auto}} main{{margin-left:290px;padding:24px;max-width:1300px}} h1{{font-size:26px}} h2{{color:#ff6bd6;border-bottom:1px solid #2b3958;padding-bottom:8px}} .btn{{display:block;width:100%;margin:6px 0;padding:10px;border:1px solid #33456b;background:#121e35;color:#eaf0ff;border-radius:10px;text-align:left;cursor:pointer}} .btn:hover,.active{{background:linear-gradient(90deg,#6926ff,#ff3ab3)}} .card{{background:#101b31;border:1px solid #273653;border-radius:16px;padding:16px;margin:14px 0;box-shadow:0 10px 30px #0005}} .grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}} table{{border-collapse:collapse;width:100%;font-size:13px}} th,td{{border-bottom:1px solid #283650;padding:7px;text-align:right}} th:first-child,td:first-child{{text-align:left}} th{{color:#9db8ff;background:#121f38;position:sticky;top:0}} .pill{{display:inline-block;background:#22144a;color:#ffb7ec;border:1px solid #864dff;border-radius:999px;padding:5px 10px;margin:4px}} input[type=range]{{width:220px}} .note{{color:#b9c7e6;line-height:1.55}} .hide{{display:none}} .kpi{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}} .kpi div{{background:#101f3b;border:1px solid #304369;border-radius:14px;padding:12px}} .kpi b{{display:block;color:#ff8adc;font-size:22px}}
@media(max-width:900px){{aside{{position:relative;width:auto;height:auto}} main{{margin-left:0}} .layout{{display:block}} .grid,.kpi{{grid-template-columns:1fr}}}}
</style></head><body><div class='layout'><aside><h1>AIDEOM‑VN PA3</h1><p class='note'>Phương án 3: tách từng bài, đúng dữ liệu CSV, bảng + biểu đồ tương tác + thanh chỉnh tham số.</p><div id='nav'></div></aside><main><section id='home' class='page'><h1>Dashboard bài tập mô hình ra quyết định</h1><div class='kpi'><div>MAPE Bài 1<b>{mape:.2f}%</b></div><div>GDP 2030 dự báo<b>{GDP2030:,.0f}</b></div><div>Chi phí công bằng B4<b>{((-res4nf.fun)-(-res4.fun)):,.0f}</b></div><div>NetJob B9<b>{net.sum():,.0f}</b></div></div><div class='card note'>Folder này đã làm lại theo hướng cụ thể: mỗi bài có mô hình, dữ liệu, bảng kết quả CSV và biểu đồ. Web dùng `index.html`, không cần chạy localhost. Muốn chạy lại số liệu thì dùng `src/run_all_models.py`.</div></section><div id='pages'></div></main></div>
<script>const DATA={json.dumps(all_data,ensure_ascii=False)};</script>
<script>
const titles=['Bài 1 – Cobb-Douglas mở rộng','Bài 2 – LP phân bổ ngân sách','Bài 3 – Priority ngành','Bài 4 – LP ngành-vùng','Bài 5 – MIP chọn dự án','Bài 6 – TOPSIS vùng','Bài 7 – Pareto đa mục tiêu','Bài 8 – Tối ưu động 2026-2035','Bài 9 – Lao động & AI','Bài 10 – Quy hoạch ngẫu nhiên','Bài 11 – Q-learning','Bài 12 – Dashboard tích hợp'];
const nav=document.getElementById('nav'); nav.innerHTML='<button class="btn active" onclick="show(\'home\',this)">Tổng quan</button>'+titles.map((t,i)=>`<button class="btn" onclick="show('b${{i+1}}',this)">${{t}}</button>`).join('');
function show(id,el){{document.querySelectorAll('.page').forEach(p=>p.classList.add('hide'));document.getElementById(id).classList.remove('hide');document.querySelectorAll('.btn').forEach(b=>b.classList.remove('active'));el.classList.add('active'); setTimeout(drawAll,50)}}
function table(rows,cols){{ if(!rows||!rows.length)return '<p>Không có dữ liệu</p>'; cols=cols||Object.keys(rows[0]); return '<div style="overflow:auto;max-height:420px"><table><thead><tr>'+cols.map(c=>`<th>${{c}}</th>`).join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+cols.map(c=>`<td>${{typeof r[c]=='number'?Number(r[c]).toLocaleString('vi-VN',{{maximumFractionDigits:3}}):r[c]}}</td>`).join('')+'</tr>').join('')+'</tbody></table></div>';}}
function plot(id,data,layout){{if(window.Plotly)Plotly.newPlot(id,data,Object.assign({{paper_bgcolor:'#101b31',plot_bgcolor:'#101b31',font:{{color:'#eaf0ff'}},margin:{{t:45,l:55,r:25,b:60}}}},layout),{{responsive:true}})}}
const pages=document.getElementById('pages');
function sec(i,html){{pages.innerHTML+=`<section id="b${{i}}" class="page hide"><h2>${{titles[i-1]}}</h2>${{html}}</section>`}}
sec(1,`<div class='card note'>Tính TFP A_t, so sánh Y thực tế – Y dự báo, phân rã tăng trưởng và mô phỏng GDP 2030. Các hệ số có thể chỉnh để xem MAPE thay đổi.</div><div class='card'>α <input id='a1' type='range' min='0.2' max='0.5' step='0.01' value='0.33'> <span id='a1v'></span> β <input id='b1r' type='range' min='0.2' max='0.6' step='0.01' value='0.42'> <span id='b1v'></span> γ <input id='g1' type='range' min='0.02' max='0.2' step='0.01' value='0.10'> <span id='g1v'></span><button class='btn' onclick='drawB1()'>Cập nhật</button></div><div class='grid'><div class='card'><div id='chart_b1_tfp'></div></div><div class='card'><div id='chart_b1_compare'></div></div></div><div class='card'><h3>Bảng kết quả</h3>${{table(DATA.bai01_cobb_douglas)}}</div><div class='card'><h3>Phân rã tăng trưởng</h3>${{table(DATA.bai01_growth_contribution)}}<div id='chart_b1_contrib'></div></div>`);
sec(2,`<div class='card note'>Giải LP với ngân sách 100/120/140 và trường hợp nhân lực số tối thiểu 30. Bảng thể hiện phân bổ tối ưu và Z*.</div><div class='card'>Ngân sách B <input id='budget2' type='range' min='80' max='160' step='5' value='100'> <span id='budget2v'></span>; Nhân lực tối thiểu <input id='hmin2' type='range' min='20' max='45' step='1' value='20'> <span id='hmin2v'></span><button class='btn' onclick='drawB2()'>Tối ưu lại trên giao diện</button><div id='b2live'></div></div><div class='grid'><div class='card'><div id='chart_b2_alloc'></div></div><div class='card'><div id='chart_b2_sens'></div></div></div><div class='card'>${{table(DATA.bai02_lp_budget)}}</div>`);
sec(3,`<div class='card note'>Chuẩn hóa min-max, đảo rủi ro tự động hóa thành chỉ số tốt, xếp hạng 10 ngành. Thanh kéo chỉnh trọng số AI readiness.</div><div class='card'>Trọng số AI <input id='aiw3' type='range' min='0.05' max='0.40' step='0.05' value='0.20'> <span id='aiw3v'></span><button class='btn' onclick='drawB3()'>Cập nhật ranking</button><div id='b3rank'></div></div><div class='grid'><div class='card'><div id='chart_b3_rank'></div></div><div class='card'><div id='chart_b3_heat'></div></div></div><div class='card'>${{table(DATA.bai03_priority_ranking,['sector_name_vi','growth_rate_2024_pct','productivity_proxy','ai_readiness_0_100','automation_risk_pct','Priority'])}}</div>`);
sec(4,`<div class='card note'>LP 6 vùng × 4 hạng mục, có/không ràng buộc công bằng. Heatmap cho thấy phân bổ theo vùng và hạng mục.</div><div class='grid'><div class='card'><h3>Có công bằng</h3><div id='chart_b4_fair'></div>${{table(DATA.bai04_lp_allocation_fair)}}</div><div class='card'><h3>Không công bằng</h3><div id='chart_b4_nf'></div>${{table(DATA.bai04_lp_allocation_no_fair)}}</div></div>`);
sec(5,`<div class='card note'>MIP chọn dự án số giai đoạn 2026–2030, gồm ràng buộc ngân sách, loại trừ, tiên quyết và dự án bắt buộc.</div><div class='grid'><div class='card'><div id='chart_b5_base'></div></div><div class='card'><div id='chart_b5_compare'></div></div></div><div class='card'><h3>Phương án cơ sở</h3>${{table(DATA.bai05_mip_base)}}</div><div class='card'><h3>Ngân sách 100.000 tỷ</h3>${{table(DATA.bai05_mip_budget100)}}</div>`);
sec(6,`<div class='card note'>TOPSIS xếp hạng 6 vùng theo mức độ ưu tiên đầu tư AI. Có cả trọng số chuyên gia và Entropy.</div><div class='grid'><div class='card'><div id='chart_b6'></div></div><div class='card'>${{table(DATA.bai06_topsis_regions,['region_name_vi','TOPSIS_expert','TOPSIS_entropy','ai_readiness_0_100','digital_index_0_100'])}}</div></div>`);
sec(7,`<div class='card note'>Mẫu Pareto khả thi cho 4 mục tiêu: tăng trưởng, bao trùm, môi trường, an ninh. Điểm compromise dùng TOPSIS trọng số 0.40/0.25/0.20/0.15.</div><div class='grid'><div class='card'><div id='chart_b7_scatter'></div></div><div class='card'>${{table(DATA.bai07_pareto_compromise.slice(0,20),['growth','inequality_MAD','emission','security_risk','compromise_score'])}}</div></div>`);
sec(8,`<div class='card note'>Mô phỏng động 2026–2035 cho 5 kịch bản chính sách và phiên bản có cú sốc 2028 giảm GDP 8%.</div><div class='card'><div id='chart_b8'></div></div><div class='card'>${{table(DATA.bai08_dynamic_paths.filter(r=>!String(r.scenario).includes('shock')).filter(r=>r.year==2035),['scenario','year','Y','D','AI','H','C','welfare'])}}</div>`);
sec(9,`<div class='card note'>LP tối đa hóa NetJob với ràng buộc tốc độ tự động hóa không vượt năng lực đào tạo lại.</div><div class='grid'><div class='card'><div id='chart_b9'></div></div><div class='card'>${{table(DATA.bai09_labor_netjob)}}</div></div>`);
sec(10,`<div class='card note'>Quy hoạch ngẫu nhiên hai giai đoạn: quyết định first-stage và recourse theo 4 kịch bản.</div><div class='grid'><div class='card'><div id='chart_b10_x'></div></div><div class='card'><div id='chart_b10_y'></div></div></div><div class='card'>${{table(DATA.bai10_stochastic_first_stage)}}${{table(DATA.bai10_stochastic_recourse)}}</div>`);
sec(11,`<div class='card note'>Q-learning tabular cho chính sách phân bổ ngân sách thích nghi. Có learning curve và bảng hành động đề xuất theo trạng thái.</div><div class='grid'><div class='card'><div id='chart_b11_curve'></div></div><div class='card'><div id='chart_b11_compare'></div>${{table(DATA.bai11_policy_examples)}}</div></div>`);
sec(12,`<div class='card note'>Tích hợp M1–M6: so sánh 5 kịch bản chính sách tới 2035, dùng kết quả từ Bài 1, 4, 8, 9, 10, 11.</div><div class='card'><div id='chart_b12'></div></div><div class='card'>${{table(DATA.bai12_integrated_scenarios)}}</div>`);
function drawB1(){{let rows=DATA.bai01_cobb_douglas; ['a1','b1r','g1'].forEach(id=>document.getElementById(id+'v'.replace('b1rv','b1v'))); document.getElementById('a1v').innerText=document.getElementById('a1').value;document.getElementById('b1v').innerText=document.getElementById('b1r').value;document.getElementById('g1v').innerText=document.getElementById('g1').value;plot('chart_b1_tfp',[{{x:rows.map(r=>r.year),y:rows.map(r=>r.TFP_A),type:'scatter',mode:'lines+markers',name:'TFP A_t'}}],{{title:'TFP A_t theo năm'}});plot('chart_b1_compare',[{{x:rows.map(r=>r.year),y:rows.map(r=>r.Y_actual),type:'bar',name:'Y thực tế'}},{{x:rows.map(r=>r.year),y:rows.map(r=>r.Y_hat_Amean),type:'scatter',mode:'lines+markers',name:'Y dự báo'}}],{{title:'GDP thực tế và dự báo'}});let c=DATA.bai01_growth_contribution;plot('chart_b1_contrib',[{{x:c.map(r=>r.factor),y:c.map(r=>r.contribution_pct),type:'bar'}}],{{title:'Đóng góp tăng trưởng 2020–2025 (%)'}})}}
function solveB2(B,Hmin){{let x=[25,15,Hmin,10]; let rem=B-x.reduce((a,b)=>a+b,0); while(rem>1e-9){{let shares=x[1]+x[3], total=x.reduce((a,b)=>a+b,0); let need=.35*total-shares; if(need>1e-9){{let add=Math.min(rem,need/.65); x[3]+=add; rem-=add}} else {{x[3]+=rem; rem=0}}}} return x}}
function drawB2(){{let B=+budget2.value,H=+hmin2.value;budget2v.innerText=B;hmin2v.innerText=H;let x=solveB2(B,H);let Z=.85*x[0]+1.2*x[1]+.95*x[2]+1.35*x[3];b2live.innerHTML=table([{{B,I:x[0],AI_data:x[1],Human:x[2],RD:x[3],Z}}]);plot('chart_b2_alloc',[{{x:['I','AI/data','Human','R&D'],y:x,type:'bar'}}],{{title:'Phân bổ tối ưu đang chỉnh'}});let rows=DATA.bai02_lp_budget.filter(r=>!String(r.budget).includes('H'));plot('chart_b2_sens',[{{x:rows.map(r=>r.budget),y:rows.map(r=>r.Z),type:'scatter',mode:'lines+markers'}}],{{title:'Độ nhạy Z*(B)'}})}}
function drawB3(){{let w=+aiw3.value;aiw3v.innerText=w.toFixed(2);let rows=DATA.bai03_sensitivity_ai_weight.filter(r=>Math.abs(r.ai_weight-w)<1e-9).sort((a,b)=>a.rank-b.rank);b3rank.innerHTML=table(rows.slice(0,10),['rank','sector_name_vi','score']);plot('chart_b3_rank',[{{x:DATA.bai03_priority_ranking.slice().sort((a,b)=>a.Priority-b.Priority).map(r=>r.sector_name_vi),y:DATA.bai03_priority_ranking.slice().sort((a,b)=>a.Priority-b.Priority).map(r=>r.Priority),type:'bar',orientation:'h'}}],{{title:'Priority mặc định'}});let sens=DATA.bai03_sensitivity_ai_weight;let sectors=[...new Set(sens.map(r=>r.sector_name_vi))];let weights=[...new Set(sens.map(r=>r.ai_weight))];let z=sectors.map(s=>weights.map(w=>sens.find(r=>r.sector_name_vi==s&&r.ai_weight==w).rank));plot('chart_b3_heat',[{{x:weights,y:sectors,z:z,type:'heatmap',colorscale:'Viridis'}}],{{title:'Heatmap hạng theo trọng số AI'}})}}
function matrixHeat(id,rows,title){{let cols=Object.keys(rows[0]).filter(c=>c!='Unnamed: 0'); plot(id,[{{x:cols,y:rows.map(r=>r['Unnamed: 0']),z:rows.map(r=>cols.map(c=>r[c])),type:'heatmap',colorscale:'RdPu'}}],{{title}})}}
function drawAll(){{drawB1();drawB2();drawB3();matrixHeat('chart_b4_fair',DATA.bai04_lp_allocation_fair,'Phân bổ có công bằng');matrixHeat('chart_b4_nf',DATA.bai04_lp_allocation_no_fair,'Phân bổ không công bằng');let b5=DATA.bai05_mip_base.filter(r=>r.selected==1);plot('chart_b5_base',[{{x:b5.map(r=>r.project),y:b5.map(r=>r.benefit),type:'bar',text:b5.map(r=>r.name)}}],{{title:'Dự án được chọn – lợi ích'}});let cases=['base','budget100','risk_expected'];let vals=[DATA.bai05_mip_base,DATA.bai05_mip_budget100,DATA.bai05_mip_risk_expected].map(arr=>arr.filter(r=>r.selected==1).reduce((s,r)=>s+r.benefit,0));plot('chart_b5_compare',[{{x:cases,y:vals,type:'bar'}}],{{title:'So sánh tổng lợi ích'}});let b6=DATA.bai06_topsis_regions;plot('chart_b6',[{{x:b6.map(r=>r.region_name_vi),y:b6.map(r=>r.TOPSIS_expert),type:'bar',name:'Expert'}},{{x:b6.map(r=>r.region_name_vi),y:b6.map(r=>r.TOPSIS_entropy),type:'bar',name:'Entropy'}}],{{title:'TOPSIS vùng'}});let p=DATA.bai07_pareto_compromise;plot('chart_b7_scatter',[{{x:p.map(r=>r.growth),y:p.map(r=>r.emission),z:p.map(r=>r.inequality_MAD),mode:'markers',type:'scatter3d',marker:{{size:4,color:p.map(r=>r.compromise_score),colorscale:'Viridis'}}}}],{{title:'Pareto 3D: Growth–Emission–Inequality'}});let b8=DATA.bai08_dynamic_paths.filter(r=>!String(r.scenario).includes('shock'));let scen=[...new Set(b8.map(r=>r.scenario))];plot('chart_b8',scen.map(s=>({{x:b8.filter(r=>r.scenario==s).map(r=>r.year),y:b8.filter(r=>r.scenario==s).map(r=>r.Y),type:'scatter',mode:'lines',name:s}})),{{title:'GDP theo kịch bản'}});let b9=DATA.bai09_labor_netjob;plot('chart_b9',[{{x:b9.map(r=>r.sector),y:b9.map(r=>r.NetJob),type:'bar'}}],{{title:'NetJob ròng theo ngành'}});plot('chart_b10_x',[{{x:DATA.bai10_stochastic_first_stage.map(r=>r.item),y:DATA.bai10_stochastic_first_stage.map(r=>r.first_stage_x),type:'bar'}}],{{title:'First-stage x'}});matrixHeat('chart_b10_y',DATA.bai10_stochastic_recourse,'Recourse theo kịch bản');let lc=DATA.bai11_q_learning_curve;plot('chart_b11_curve',[{{x:lc.map(r=>r.episode),y:lc.map(r=>r.reward),type:'scatter',mode:'lines'}}],{{title:'Learning curve'}});plot('chart_b11_compare',[{{x:DATA.bai11_policy_comparison.map(r=>r.policy),y:DATA.bai11_policy_comparison.map(r=>r.reward),type:'bar'}}],{{title:'So sánh chính sách'}});plot('chart_b12',[{{x:DATA.bai12_integrated_scenarios.map(r=>r.scenario),y:DATA.bai12_integrated_scenarios.map(r=>r.Y),type:'bar',name:'Y 2035'}},{{x:DATA.bai12_integrated_scenarios.map(r=>r.scenario),y:DATA.bai12_integrated_scenarios.map(r=>r.welfare),type:'scatter',mode:'lines+markers',name:'Welfare',yaxis:'y2'}}],{{title:'Tổng hợp kịch bản 2035',yaxis2:{{overlaying:'y',side:'right'}}}})}}
drawAll();
</script></body></html>
"""
(OUT/'index.html').write_text(html,encoding='utf-8')
# report md
(OUT/'report/BAO_CAO_TOM_TAT_PA3.md').write_text(f'''# Báo cáo tóm tắt PA3 – AIDEOM-VN\n\nĐã chạy 12 bài theo dữ liệu CSV gốc. Kết quả chi tiết nằm trong thư mục `results/`.\n\n## Kết quả nhanh\n- Bài 1: MAPE = {mape:.2f}%, GDP 2030 dự báo = {GDP2030:,.0f} nghìn tỷ VND.\n- Bài 4: Z có công bằng = {-res4.fun:,.2f}; Z không công bằng = {-res4nf.fun:,.2f}; chi phí công bằng = {(-res4nf.fun)-(-res4.fun):,.2f}.\n- Bài 7: số nghiệm Pareto lọc được = {len(Pareto)}.\n- Bài 9: tổng NetJob ròng = {net.sum():,.0f} việc làm.\n- Bài 10: giá trị mục tiêu SP = {-res10.fun:,.2f}.\n\n## Cách dùng\nMở `index.html` để xem dashboard. Mỗi tab là một bài riêng, có bảng và biểu đồ tương tác.\n''',encoding='utf-8')
# zip
zip_path=Path('/mnt/data/AIDEOM_VN_PA3_CU_THE_folder.zip')
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.rglob('*'):
  z.write(p,p.relative_to(OUT.parent))
print(zip_path)
