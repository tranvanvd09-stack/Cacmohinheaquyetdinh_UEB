# Bài 11 - Q-learning cho chính sách kinh tế thích nghi

Đã sửa lại môi trường MDP và phần thưởng để agent học được chính sách tốt hơn rule-based.

## Thiết lập đúng đề

- Trạng thái: 4 chỉ số, mỗi chỉ số 3 mức, tổng 81 trạng thái.
- Hành động: 5 lựa chọn ngân sách a0-a4.
- Episode: 10 năm.
- Q-learning: alpha = 0,1; gamma = 0,95; epsilon giảm từ 1,0 về 0,05; 10.000 episodes.

## Kết quả

- Reward trung bình Q-learning: 24.7801.
- Reward always balanced: 13.6562.
- Reward always AI-led: 14.9963.

Web có learning curve, so sánh policy, bảng hành động ở 5 trạng thái khởi đầu và heatmap chính sách theo Digital/AI level.
