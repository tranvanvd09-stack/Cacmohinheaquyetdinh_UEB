# Bài 12. Đồ án tích hợp AIDEOM-VN

## 1. Mục tiêu bài
Làm riêng bài 12 theo dữ liệu gốc trong thư mục `data_goc/`, không trộn lẫn với bài khác. Kết quả CSV của bài này nằm ngay trong cùng thư mục.

## 2. Mô hình sử dụng
Tích hợp Cobb-Douglas, LP, TOPSIS, động học, lao động, bất định và Q-learning để ra khuyến nghị.

## 3. Kết quả chính
Tổng hợp đầu ra từ các bài trước thành dashboard kịch bản chính sách 2035.

## 4. Bảng kết quả đi kèm

### bai12_integrated_scenarios.csv

| scenario        |       Y |       D |       AI |       H |   welfare | risk_note                          |
|:----------------|--------:|--------:|---------:|--------:|----------:|:-----------------------------------|
| S1_Truyen_thong | 12592.3 | 21.7579 |  88.9725 | 36.1449 |   80.1661 | Cơ sở đối chứng                    |
| S2_So_hoa_nhanh | 13434.2 | 79.639  | 129.96   | 42.6509 |   80.6282 | CĐS nhanh, rủi ro hạ tầng vừa      |
| S3_AI_dan_dat   | 13321.7 | 38.8966 | 349.279  | 42.6267 |   80.6139 | AI cao, cần quản trị dữ liệu       |
| S4_Bao_trum     | 12663.3 | 37.4613 |  89.8102 | 70.0612 |   80.2602 | Bao trùm tốt, tăng trưởng chậm hơn |
| S5_Can_bang     | 13372.4 | 46.5246 | 128.414  | 48.1976 |   80.5125 | Cân bằng khuyến nghị               |

## 5. Cách xem biểu đồ
Mở `dashboard/index.html`, chọn tab Bài 12. Biểu đồ trong dashboard là Plotly tương tác, có thể rê chuột xem số liệu, phóng to, tải ảnh và chỉnh các tham số ở những bài có slider.
