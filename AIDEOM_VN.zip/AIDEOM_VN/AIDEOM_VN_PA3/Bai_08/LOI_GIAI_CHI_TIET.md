# Bài 8. Tối ưu động phân bổ liên thời gian 2026-2035

## 1. Mục tiêu bài
Làm riêng bài 8 theo dữ liệu gốc trong thư mục `data_goc/`, không trộn lẫn với bài khác. Kết quả CSV của bài này nằm ngay trong cùng thư mục.

## 2. Mô hình sử dụng
Mô hình trạng thái K, D, AI, H theo thời gian; phúc lợi tích lũy bằng tổng chiết khấu log(C_t).

## 3. Kết quả chính
Mô phỏng 5 kịch bản chính sách, có kịch bản cú sốc 2028 để so sánh khả năng phục hồi.

## 4. Bảng kết quả đi kèm

### bai08_dynamic_paths.csv

| scenario              |   year |       K |       D |      AI |       H |       Y |       C |   welfare |
|:----------------------|-------:|--------:|--------:|--------:|--------:|--------:|--------:|----------:|
| S1_Truyen_thong       |   2026 | 27500   | 20.3    | 86      | 30      | 11805.2 | 9208.09 |   9.12784 |
| S1_Truyen_thong       |   2027 | 27943   | 20.4612 | 86.0858 | 30.6986 | 11897.2 | 9279.78 |  17.9894  |
| S1_Truyen_thong       |   2028 | 28378   | 20.6232 | 86.2598 | 31.3933 | 11988.1 | 9350.71 |  26.5922  |
| S1_Truyen_thong       |   2029 | 28805.3 | 20.7858 | 86.5077 | 32.0841 | 12078   | 9420.82 |  34.9438  |
| S1_Truyen_thong       |   2030 | 29225   | 20.9486 | 86.8173 | 32.771  | 12166.8 | 9490.07 |  43.0513  |
| S1_Truyen_thong       |   2031 | 29637.5 | 21.1115 | 87.1782 | 33.4539 | 12254.4 | 9558.4  |  50.9217  |
| S1_Truyen_thong       |   2032 | 30042.8 | 21.2741 | 87.5812 | 34.1328 | 12340.7 | 9625.78 |  58.5619  |
| S1_Truyen_thong       |   2033 | 30441.1 | 21.4361 | 88.0189 | 34.8077 | 12425.9 | 9692.18 |  65.9785  |
| S1_Truyen_thong       |   2034 | 30832.6 | 21.5975 | 88.4845 | 35.4784 | 12509.7 | 9757.58 |  73.1778  |
| S1_Truyen_thong       |   2035 | 31217.5 | 21.7579 | 88.9725 | 36.1449 | 12592.3 | 9821.97 |  80.1661  |
| S1_Truyen_thong_shock |   2026 | 27500   | 20.3    | 86      | 30      | 11805.2 | 9208.09 |   9.12784 |
| S1_Truyen_thong_shock |   2027 | 27943   | 20.4612 | 86.0858 | 30.6986 | 11897.2 | 9279.78 |  17.9894  |

## 5. Cách xem biểu đồ
Mở `dashboard/index.html`, chọn tab Bài 08. Biểu đồ trong dashboard là Plotly tương tác, có thể rê chuột xem số liệu, phóng to, tải ảnh và chỉnh các tham số ở những bài có slider.
