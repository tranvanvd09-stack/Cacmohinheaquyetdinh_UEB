# Bài 1. Hàm sản xuất Cobb-Douglas mở rộng với AI và số hóa

## 1. Mục tiêu bài
Làm riêng bài 1 theo dữ liệu gốc trong thư mục `data_goc/`, không trộn lẫn với bài khác. Kết quả CSV của bài này nằm ngay trong cùng thư mục.

## 2. Mô hình sử dụng
Y = A·K^α·L^β·D^γ·AI^δ·H^θ; hiệu chỉnh A_t từ GDP thực tế 2020-2025, sau đó mô phỏng 2030.

## 3. Kết quả chính
MAPE = 6.42%, dự báo GDP 2030 = 18,262 nghìn tỷ VND.

## 4. Bảng kết quả đi kèm

### bai01_cobb_douglas.csv

|   year |   Y_actual |     K |    L |    D |   AI |    H |   TFP_A |   Y_hat_Amean |   abs_pct_error |
|-------:|-----------:|------:|-----:|-----:|-----:|-----:|--------:|--------------:|----------------:|
|   2020 |     8044.4 | 16500 | 53.6 | 12   | 55.6 | 24.1 | 27.7466 |       8971.52 |      11.525     |
|   2021 |     8487.5 | 17800 | 50.5 | 12.7 | 60.2 | 26.1 | 28.7638 |       9130.94 |       7.58107   |
|   2022 |     9513.3 | 19600 | 51.7 | 14.3 | 65.4 | 26.2 | 30.3501 |       9699.59 |       1.95816   |
|   2023 |    10221.8 | 21300 | 52.4 | 16.5 | 67   | 27   | 30.9751 |      10211.7  |       0.0992818 |
|   2024 |    11511.9 | 23500 | 52.9 | 18.3 | 73.8 | 28.4 | 32.9171 |      10822    |       5.99295   |
|   2025 |    12847.6 | 25900 | 53.4 | 19.5 | 80.1 | 29.2 | 34.9136 |      11387    |      11.3688    |

### bai01_growth_contribution.csv

| factor   |   contribution_pct |
|:---------|-------------------:|
| K        |          31.7807   |
| L        |          -0.335361 |
| D        |          10.3701   |
| AI       |           6.23849  |
| H        |           2.87004  |
| TFP      |          49.076    |

## 5. Cách xem biểu đồ
Mở `dashboard/index.html`, chọn tab Bài 01. Biểu đồ trong dashboard là Plotly tương tác, có thể rê chuột xem số liệu, phóng to, tải ảnh và chỉnh các tham số ở những bài có slider.
